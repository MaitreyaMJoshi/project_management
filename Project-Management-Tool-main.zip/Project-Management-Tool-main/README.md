## Project Management Tool
🚀Project Update🚀<br>
This is my TASK-2 "Project Management Tool" as part of my Internship with Bharat Intern.

<a href="https://epavan162.github.io/Project-Management-Tool/" target="_blank"><br>
🚀**Visit Now** 🚀</a>


## 📌 Home Page of Project Management Tool 🙈 :


![Screenshot 2023-09-04 163824](https://github.com/epavan162/Project-Management-Tool/assets/102135027/9950ada9-00d0-452f-9caf-83a9944a2daa)



<h3>If you want to know more about my Project </3>
<a href="https://epavan162.github.io/Project-Management-Tool/" target="_blank"> &emsp;🚀 **Visit Now** 🚀</a>

<h2>📬 Contact</h2>


If you want to contact me, you can reach me through below handles.<br>

<a href="https://www.linkedin.com/in/edagottu-pavan-kalyan-281681236/"><img alt="LinkedIn" src="https://img.shields.io/badge/linkedin-%230077B5.svg?style=for-the-badge&logo=linkedin&logoColor=white"/></a>
<a href="mailto:epavan162@gmail.com"><img alt="Gmail" src="https://img.shields.io/badge/Gmail-D14836?style=for-the-badge&logo=gmail&logoColor=white"/></a>
<a href="https://www.instagram.com/mr_innocent_kid420"><img alt="Instagram" src="https://img.shields.io/badge/Instagram-E4405F?style=for-the-badge&logo=instagram&logoColor=white"/></a>
<a href="https://t.me/edagottupavankalyan162"><img alt="Telegram" src="https://img.shields.io/badge/Telegram-2CA5E0?style=for-the-badge&logo=telegram&logoColor=white" /></a>


© 2023 Edagottu Pavan Kalyan
